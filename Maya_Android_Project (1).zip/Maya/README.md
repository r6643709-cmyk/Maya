# MAYA - JARVIS style Hindi AI assistant for Android (for Ankit)

Flow: Voice -> SpeechRecognizer (hi-IN) -> Gemini (free API key) -> Hindi female TTS -> Phone/Web actions.

## Setup
1. Get a free key: https://aistudio.google.com/apikey
2. Open this folder in Android Studio, let Gradle sync, run on your phone (USB debugging).
3. In the app: save key -> grant permissions -> enable "Maya Controller" in Accessibility
   -> allow overlay -> set battery to Unrestricted -> START MAYA.
4. Install/update "Speech Services by Google" and download Hindi (India) voice + offline Hindi speech.

## Example commands
"Maya, WhatsApp kholo" / "Maya, YouTube pe Arijit Singh ke gaane search karo"
"Maya, flashlight on karo" / "Maya, scroll down" / "Maya, Amazon kholo aur earbuds search karo"
"Maya, ye screen padho" / "Maya, band ho jao"
