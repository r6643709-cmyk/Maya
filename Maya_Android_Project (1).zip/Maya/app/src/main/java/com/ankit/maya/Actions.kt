package com.ankit.maya

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.delay

object Actions {
    /** Runs one action. Returns screen text for read_screen, else a short status. */
    suspend fun run(ctx: Context, type: String, value: String): String {
        val acc = MayaAccessibility.instance
        try {
            when (type) {
                "open_app" -> return if (openApp(ctx, value)) "ok" else "app not found: $value"
                "open_url" -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(value)))
                "search_web" -> launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(value))))
                "youtube_search" -> launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(value))))
                "call" -> {
                    val num = Uri.parse("tel:" + value.filter { it.isDigit() || it == '+' })
                    val granted = ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0
                    launch(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, num))
                }
                "wait" -> delay((value.toLongOrNull() ?: 1000L).coerceIn(200, 8000))
                "flashlight_on", "flashlight_off" -> {
                    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    cm.setTorchMode(cm.cameraIdList[0], type == "flashlight_on")
                }
                "volume_up", "volume_down" -> {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        if (type == "volume_up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI)
                }
                // Accessibility based controls
                "back" -> acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: return noAcc()
                "home" -> acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: return noAcc()
                "recents" -> acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: return noAcc()
                "notifications" -> acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: return noAcc()
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28)
                    acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: return noAcc()
                "scroll_down" -> acc?.scroll(true) ?: return noAcc()
                "scroll_up" -> acc?.scroll(false) ?: return noAcc()
                "click_text" -> return if (acc == null) noAcc() else if (acc.clickText(value)) "clicked" else "text not found: $value"
                "type_text" -> return if (acc == null) noAcc() else if (acc.typeText(value)) "typed" else "no input field"
                "enter" -> acc?.pressEnter() ?: return noAcc()
                "read_screen" -> return acc?.readScreen() ?: noAcc()
            }
        } catch (e: Exception) {
            return "error: ${e.message}"
        }
        return "ok"
    }

    private fun noAcc() = "Accessibility service is OFF. Ask Ankit to enable Maya Controller."

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.lowercase().trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch(ctx, i)
        return true
    }
}
