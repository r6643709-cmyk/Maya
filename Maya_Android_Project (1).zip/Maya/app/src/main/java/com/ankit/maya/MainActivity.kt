package com.ankit.maya

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("maya", Context.MODE_PRIVATE)
        val dp = resources.displayMetrics.density
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05070D"))
            setPadding((24 * dp).toInt(), (48 * dp).toInt(), (24 * dp).toInt(), (24 * dp).toInt())
        }
        root.addView(TextView(this).apply {
            text = "M A Y A"; textSize = 38f; setTextColor(Color.parseColor("#27E1FF")); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Personal AI for Ankit"; setTextColor(Color.GRAY); gravity = Gravity.CENTER
        })
        val key = EditText(this).apply {
            hint = "Gemini API key (aistudio.google.com/apikey)"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setText(prefs.getString("key", ""))
        }
        root.addView(key)
        root.addView(btn("1. Save API key") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("2. Permissions (mic, call, notifications)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA), 1)
        })
        root.addView(btn("3. Enable phone control (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("4. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("5. Battery: allow background (Unrestricted)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("START MAYA") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            startForegroundService(Intent(this, MayaService::class.java))
        })
        root.addView(btn("STOP MAYA") { stopService(Intent(this, MayaService::class.java)) })
        val out = TextView(this).apply { setTextColor(Color.WHITE); setTextIsSelectable(true); setPadding(0, (16 * dp).toInt(), 0, 0) }
        root.addView(out)
        MayaService.onShow = { t -> runOnUiThread { out.text = t } }
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#05070D")) })
    }
}
