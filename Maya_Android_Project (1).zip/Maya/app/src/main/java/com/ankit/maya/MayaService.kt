package com.ankit.maya

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.*
import java.util.Locale

class MayaService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var pendingSpeech = 0
    @Volatile private var thinking = false
    private var awakeUntil = 0L
    private val wake = listOf("hey maya", "maya", "माया", "मायाजी", "माया जी", "मैया", "maiya")

    companion object { var onShow: ((String) -> Unit)? = null }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "maya"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Maya", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Maya active hai")
            .setContentText("\"Maya\" bolkar mujhe bulaiye, Ankit")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale("hi", "IN")
        // Prefer a female Hindi voice (Google TTS: hi-in-x-hia / hic are female)
        val hindi = tts.voices?.filter { it.locale.language == "hi" && !it.isNetworkConnectionRequired } ?: emptyList()
        val female = hindi.firstOrNull { it.name.contains("hia") }
            ?: hindi.firstOrNull { it.name.contains("hic") }
            ?: hindi.firstOrNull { it.name.contains("female", true) }
            ?: tts.voices?.firstOrNull { it.locale.language == "hi" }
        female?.let { tts.voice = it }
        tts.setPitch(1.12f)
        tts.setSpeechRate(0.97f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { done() }
            override fun onDone(id: String?) { done() }
            fun done() = main.post { pendingSpeech = (pendingSpeech - 1).coerceAtLeast(0); listen() }
        })
        ttsReady = true
        speak("नमस्ते अंकित, मैं माया हूँ। आपकी सेवा में तैयार।")
    }

    private fun speak(text: String) {
        if (!ttsReady || text.isBlank()) return
        pendingSpeech++
        recognizer?.cancel()
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (pendingSpeech > 0 || thinking) return
        main.post {
            recognizer?.destroy()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return@post
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (t.isNullOrBlank()) listen() else heard(t)
                    }
                    override fun onError(e: Int) { main.postDelayed({ listen() }, 600) }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                })
            }
        }
    }

    private fun heard(text: String) {
        val awake = System.currentTimeMillis() < awakeUntil
        val hit = wake.any { text.contains(it, ignoreCase = true) }
        if (!hit && !awake) { listen(); return }
        var cmd = text
        wake.forEach { cmd = cmd.replace(it, "", ignoreCase = true) }
        cmd = cmd.trim(' ', ',', '।', '.')
        awakeUntil = System.currentTimeMillis() + 20_000
        if (cmd.isBlank()) speak("जी अंकित, बोलिए, मैं सुन रही हूँ।") else think(cmd, 0)
    }

    private fun think(input: String, depth: Int) {
        thinking = true
        scope.launch {
            val key = getSharedPreferences("maya", Context.MODE_PRIVATE).getString("key", "") ?: ""
            if (key.isBlank()) {
                thinking = false
                speak("अंकित, पहले ऐप में अपनी Gemini API key डालिए।")
                return@launch
            }
            val r = Brain.ask(key, input)
            val disp = r.optString("display")
            if (disp.isNotBlank()) onShow?.invoke(disp)
            speak(r.optString("speech"))
            val acts = r.optJSONArray("actions")
            var screen: String? = null
            if (acts != null) {
                for (i in 0 until acts.length()) {
                    val a = acts.getJSONObject(i)
                    val type = a.optString("type")
                    if (type == "stop_maya") { stopSelf(); return@launch }
                    val out = Actions.run(this@MayaService, type, a.optString("value"))
                    if (type == "read_screen") screen = out
                    else if (out.startsWith("Accessibility") || out.startsWith("text not") || out.startsWith("app not"))
                        screen = (screen ?: "") + "[RESULT] $out\n"
                    delay(700)
                }
            }
            if (screen != null && depth < 6) {
                delay(1200)
                think("[SCREEN]\n$screen", depth + 1)
            } else {
                thinking = false
                listen()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
