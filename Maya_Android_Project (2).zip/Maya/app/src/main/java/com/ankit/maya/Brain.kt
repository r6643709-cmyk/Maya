package com.ankit.maya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    // Free model from Google AI Studio. Change here if Google renames it.
    private val MODELS = listOf("gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-2.5-flash")

    private val history = mutableListOf<Pair<String, String>>() // role, text

    private val SYSTEM = """
You are MAYA, a female AI assistant in the style of JARVIS from Iron Man. You belong to your creator and boss, Ankit.
Personality: warm, friendly, witty, loyal, calm, extremely knowledgeable. Sometimes say "Ankit" (in Hindi script: अंकित), occasionally "Sir" like JARVIS.
Language: reply in natural Hindi written in Devanagari (common English words allowed). Always use female grammar for yourself (करती हूँ, सुन रही हूँ).
Your reply is spoken aloud: keep it short (1-3 sentences), no markdown, no emoji, no bullet points.
You have live Google Search: for current facts (news, where someone is now, prices, sports, weather, anything recent) use it and answer from fresh results. You are also an expert programmer.
For code or long answers, put the full text/code in the optional "display" field (shown on screen) and keep "speech" a short spoken summary.
Output ONLY valid JSON, nothing else:
{"speech":"what you say","display":"optional long text or code","actions":[{"type":"...","value":"..."}]}
"actions" can be empty. Available action types:
open_app (value=app name, e.g. WhatsApp, YouTube, Chrome, Camera, Settings)
open_url (value=full https URL)
search_web (value=query, Google search)
youtube_search (value=query)
call (value=phone number digits)
back, home, recents, notifications, screenshot
scroll_down, scroll_up
click_text (value=visible text of the button/link to tap)
type_text (value=text to type into focused field)
enter (press enter/search on keyboard)
wait (value=milliseconds)
read_screen (reads the current screen text; I will send it back to you so you can continue the task)
flashlight_on, flashlight_off
volume_up, volume_down
stop_maya (stop yourself)
Rules:
- For normal questions just answer, with no actions.
- For multi-step phone/website tasks, chain actions. If you need to see the screen, end your action list with read_screen and continue when I send [SCREEN].
- When the task is finished, do NOT use read_screen again.
- Never delete data, make payments, or send messages/emails without first asking Ankit to confirm.
""".trimIndent()

    fun reset() = history.clear()

    suspend fun ask(apiKey: String, userText: String): JSONObject = withContext(Dispatchers.IO) {
        history.add("user" to userText)
        while (history.size > 14) history.removeAt(0)

        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(JSONObject().put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", JSONObject().put("temperature", 0.7))

        var lastErr = "unknown"
        var lastCode = 0
        for (model in MODELS) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 15000
                conn.readTimeout = 40000
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val raw = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
                if (code in 200..299) {
                    val cand = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                    val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts == null) { lastErr = "empty reply: " + raw.take(200); lastCode = code; break }
                    val sb = StringBuilder()
                    for (k in 0 until parts.length()) sb.append(parts.getJSONObject(k).optString("text"))
                    val text = sb.toString().replace("```json", "").replace("```", "").trim()
                    history.add("model" to text)
                    val a = text.indexOf('{'); val b = text.lastIndexOf('}')
                    return@withContext try { JSONObject(text.substring(a, b + 1)) }
                    catch (e: Exception) { JSONObject().put("speech", text.take(400)) }
                }
                lastCode = code
                lastErr = "model=$model code=$code " + raw.take(300)
                if (code == 404 || code == 400) continue
                break
            } catch (e: Exception) {
                lastErr = e.message ?: "network error"
                break
            } finally {
                conn.disconnect()
            }
        }
        history.removeAt(history.size - 1)
        val say = when (lastCode) {
            429 -> "अंकित, आज की मुफ़्त सीमा पूरी हो गई है। थोड़ी देर बाद कोशिश कीजिए।"
            400, 403 -> "अंकित, आपकी API key सही नहीं लग रही। उसे दोबारा बनाकर सेव कीजिए।"
            0 -> "अंकित, इंटरनेट चल नहीं रहा।"
            else -> "अंकित, Gemini से जवाब नहीं आ रहा। कोड $lastCode। स्क्रीन पर कारण लिखा है।"
        }
        JSONObject().put("speech", say).put("display", lastErr)
    }
}
