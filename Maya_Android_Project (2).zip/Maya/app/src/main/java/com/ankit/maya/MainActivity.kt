package com.ankit.maya

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var chat: TextView
    private val lines = ArrayList<String>()
    private val cyan = Color.parseColor("#27E1FF")

    private fun refresh() {
        toggle.text = if (MayaService.running) "■   माया को सुलाओ" else "▶   माया को जगाओ"
        val s = if (MayaService.running) MayaService.lastState else 0
        orb.state = s
        status.text = when (s) {
            1 -> "सुन रही हूँ..."
            2 -> "सोच रही हूँ..."
            3 -> "बोल रही हूँ..."
            else -> if (MayaService.running) "तैयार हूँ" else "आराम कर रही हूँ"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#05070D")
        window.navigationBarColor = Color.parseColor("#05070D")
        val prefs = getSharedPreferences("maya", Context.MODE_PRIVATE)
        val dp = resources.displayMetrics.density
        fun d(x: Int) = (x * dp).toInt()
        fun shape(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
            setColor(fill); cornerRadius = radius * dp; setStroke(d(1), stroke)
        }
        fun lp(top: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(top) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
            background = shape(Color.parseColor("#0E2233"), Color.parseColor("#4427E1FF"), 24)
            setOnClickListener { f() }
            layoutParams = lp(8)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(36), d(20), d(28))
        }
        root.addView(TextView(this).apply {
            text = "M A Y A"; textSize = 34f; setTextColor(cyan); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        root.addView(TextView(this).apply {
            text = "आपकी अपनी JARVIS  •  अंकित के लिए"
            setTextColor(Color.parseColor("#7D8DA0")); gravity = Gravity.CENTER
        })
        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(-1, d(320)))
        status = TextView(this).apply { textSize = 18f; setTextColor(cyan); gravity = Gravity.CENTER }
        root.addView(status)

        toggle = btn("") {
            if (MayaService.running) {
                stopService(Intent(this, MayaService::class.java))
            } else {
                val k = prefs.getString("key", "") ?: ""
                if (k.isBlank()) {
                    Toast.makeText(this, "पहले नीचे सेटिंग में API key डालकर सेव करो", Toast.LENGTH_LONG).show()
                } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "माइक की अनुमति दो (Allow दबाओ), फिर दोबारा दबाओ", Toast.LENGTH_LONG).show()
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                } else {
                    startForegroundService(Intent(this, MayaService::class.java))
                }
            }
        }.apply {
            background = shape(cyan, cyan, 30)
            setTextColor(Color.parseColor("#001018")); textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, d(14), 0, d(14))
            layoutParams = lp(16)
        }
        root.addView(toggle)

        chat = TextView(this).apply {
            text = "यहाँ हमारी बातचीत दिखेगी..."
            setTextColor(Color.parseColor("#DDEBFF")); textSize = 15f
            setLineSpacing(0f, 1.25f); setTextIsSelectable(true)
            setPadding(d(16), d(14), d(16), d(14)); minHeight = d(130)
            background = shape(Color.parseColor("#0A1621"), Color.parseColor("#3327E1FF"), 18)
        }
        root.addView(chat, lp(16))

        // Settings panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (prefs.getString("key", "").isNullOrBlank()) View.VISIBLE else View.GONE
        }
        val key = EditText(this).apply {
            hint = "Gemini API key यहाँ पेस्ट करो"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine()
            setText(prefs.getString("key", ""))
            setPadding(d(14), d(12), d(14), d(12))
            background = shape(Color.parseColor("#0A1621"), Color.parseColor("#4427E1FF"), 12)
        }
        panel.addView(key, lp(8))
        panel.addView(btn("1.  API key सेव करो") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "सेव हो गई", Toast.LENGTH_SHORT).show()
        })
        panel.addView(btn("2.  अनुमतियाँ (माइक, कॉल, नोटिफ़िकेशन)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA), 1)
        })
        panel.addView(btn("3.  फ़ोन कंट्रोल चालू करो (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        panel.addView(btn("4.  दूसरे ऐप के ऊपर दिखने दो") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        panel.addView(btn("5.  बैटरी: बैकग्राउंड में चलने दो") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("⚙   सेटिंग / अनुमतियाँ") {
            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }.apply { layoutParams = lp(16) })
        root.addView(panel)

        // show last crash, if any
        prefs.getString("crash", "")?.let {
            if (it.isNotBlank()) {
                chat.text = "पिछली बार ऐप में गड़बड़ हुई (ये मुझे भेजो):\n" + it
                prefs.edit().remove("crash").apply()
            }
        }

        MayaService.onState = { runOnUiThread { refresh() } }
        MayaService.onLine = { who, t ->
            runOnUiThread {
                lines.add(if (who.isBlank()) t else "$who: $t")
                while (lines.size > 5) lines.removeAt(0)
                chat.text = lines.joinToString("\n\n")
            }
        }
        setContentView(ScrollView(this).apply {
            addView(root); setBackgroundColor(Color.parseColor("#05070D"))
        })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        MayaService.onState = null
        MayaService.onLine = null
        super.onDestroy()
    }
}
