package com.ankit.maya

import android.app.Application
import android.content.Context

class MayaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("maya", Context.MODE_PRIVATE).edit()
                    .putString("crash", android.util.Log.getStackTraceString(e).take(1500)).commit()
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }
}
