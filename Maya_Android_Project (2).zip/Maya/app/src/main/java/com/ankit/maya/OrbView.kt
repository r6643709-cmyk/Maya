package com.ankit.maya

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*

/** JARVIS style animated orb. state: 0 rest, 1 listening, 2 thinking, 3 speaking */
class OrbView(ctx: Context) : View(ctx) {
    var state = 0
        set(v) { field = v; invalidate() }
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t += when (state) { 0 -> 0.012f; 1 -> 0.025f; 2 -> 0.04f; else -> 0.03f }
            invalidate()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun baseColor() = when (state) {
        0 -> 0xFF27E1FF.toInt()   // cyan
        1 -> 0xFF3DFFA0.toInt()   // green
        2 -> 0xFFFFC857.toInt()   // amber
        else -> 0xFFFF6BD6.toInt() // pink
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.55f
        val col = baseColor()
        fun a(alpha: Int) = Color.argb(alpha, Color.red(col), Color.green(col), Color.blue(col))

        // outer glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r * 2f, a(110), a(0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 2f, paint)

        // pulsing core
        val pulse = 1f + 0.06f * sin(t * (if (state == 3) 9f else 3f))
        val cr = r * 0.6f * pulse
        paint.shader = RadialGradient(cx, cy, cr, intArrayOf(Color.WHITE, a(230), a(40)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, cr, paint)
        paint.shader = null

        // rings
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = a(160)
        c.drawCircle(cx, cy, r * 0.8f, paint)
        paint.color = a(70)
        c.drawCircle(cx, cy, r * (1.0f + 0.05f * sin(t * 2f)), paint)

        // rotating HUD arcs
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 8f
        paint.color = a(230)
        rect.set(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f)
        for (i in 0 until 3) c.drawArc(rect, t * 70f + i * 120f, 55f, false, paint)
        paint.strokeWidth = 4f
        paint.color = a(140)
        rect.set(cx - r * 1.15f, cy - r * 1.15f, cx + r * 1.15f, cy + r * 1.15f)
        for (i in 0 until 2) c.drawArc(rect, -t * 50f + i * 180f, 80f, false, paint)

        // sound bars around
        paint.strokeWidth = 5f
        paint.color = a(200)
        val n = 60
        for (i in 0 until n) {
            val ang = (i * 360f / n) * PI.toFloat() / 180f
            val amp = when (state) {
                0 -> 0.03f + 0.02f * sin(t * 2f + i)
                1 -> 0.08f + 0.12f * abs(sin(t * 5f + i * 0.7f))
                2 -> 0.05f + 0.05f * abs(sin(t * 8f - i * 0.5f))
                else -> 0.08f + 0.20f * abs(sin(t * 7f + i * 1.3f))
            }
            val r1 = r * 1.3f
            val r2 = r1 + r * amp
            c.drawLine(cx + cos(ang) * r1, cy + sin(ang) * r1, cx + cos(ang) * r2, cy + sin(ang) * r2, paint)
        }
    }
}
